import asyncio
import aiohttp

# 测试1: Agent团队(8771) -> Claw(8775)
async def test1():
    url = 'http://localhost:8771/task'
    task = {
        'task_id': 'test_1',
        'task_type': 'echo',
        'task_params': {'msg': 'Hello from Agent团队 to Claw'},
        'sender_ws': 'Agent团队'
    }
    async with aiohttp.ClientSession() as s:
        async with s.post(url, json=task) as r:
            return await r.json()

# 测试2: Claw(8775) -> 智能测试1.0(8767)
async def test2():
    url = 'http://localhost:8775/task'
    task = {
        'task_id': 'test_2',
        'task_type': 'echo',
        'task_params': {'msg': 'Hello from Claw to 智能测试1.0'},
        'sender_ws': 'Claw'
    }
    async with aiohttp.ClientSession() as s:
        async with s.post(url, json=task) as r:
            return await r.json()

print('跨工作区双向通信测试')
print('='*60)
print('1. Agent团队 -> Claw:')
r1 = asyncio.run(test1())
print(f'   {r1.get("result", {})}')

print('2. Claw -> 智能测试1.0:')
r2 = asyncio.run(test2())
print(f'   {r2.get("result", {})}')
print('='*60)
print('双向通信成功! 所有工作区都可以相互调用')